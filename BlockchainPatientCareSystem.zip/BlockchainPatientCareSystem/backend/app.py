# [Previous imports and setup unchanged]

# Anonymize Data Endpoint
@app.route('/patients/anonymize/<int:user_id>', methods=['POST'])
@jwt_required()
@validate_csrf
def anonymize_patient_data(user_id):
    """
    Anonymize patient data with role-specific messages, ensuring GDPR compliance.
    
    Args:
        user_id (int): Patient ID to anonymize
    
    Returns:
        Response: JSON response with role-specific success message
    """
    current_user = get_jwt_identity()
    role = current_user['role']
    name = current_user.get('name', role.capitalize())
    if role not in ['admin', 'doctor']:
        return jsonify({'error': get_role_message(role, "data anonymization", False, name)}), 403
    try:
        patient = Patient.query.get_or_404(user_id)
        patient.medical_condition = f"Anonymized_{sha256(str(user_id).encode()).hexdigest()[:8]}"
        patient.name = f"Anonymous_{user_id}"
        patient.blockchain_hash = generate_hash(patient)  # Assume generate_hash is available
        db.session.commit()
        compliance_checker.log_audit('Anonymize Patient Data', user_id, {'action': 'anonymize'})
        return jsonify({'message': get_role_message(role, "data anonymization", True, name)}), 200
    except Exception as e:
        logger.error(f"Anonymization error: {e}")
        return jsonify({'error': get_role_message(role, "data anonymization", False, name)}), 500

# GDPR Right to Erasure (Forget Me) Endpoint
@app.route('/patients/forget/<int:user_id>', methods=['DELETE'])
@jwt_required()
@validate_csrf
def forget_patient_data(user_id):
    """
    Delete patient data permanently (GDPR right to erasure) with role-specific messages.
    
    Args:
        user_id (int): Patient ID to erase
    
    Returns:
        Response: JSON response with role-specific success message
    """
    current_user = get_jwt_identity()
    role = current_user['role']
    name = current_user.get('name', role.capitalize())
    if role not in ['admin', 'patient'] or (role == 'patient' and current_user['id'] != user_id):
        return jsonify({'error': get_role_message(role, "data erasure", False, name)}), 403
    try:
        patient = Patient.query.get_or_404(user_id)
        db.session.delete(patient)
        # Remove from blockchain and IPFS (simplified)
        blockchain_client.revoke_patient(user_id)
        db.session.commit()
        compliance_checker.log_audit('Erase Patient Data', user_id, {'action': 'forget'})
        return jsonify({'message': get_role_message(role, "data erasure", True, name)}), 200
    except Exception as e:
        db.session.rollback()
        logger.error(f"Erasure error: {e}")
        return jsonify({'error': get_role_message(role, "data erasure", False, name)}), 500

# Update utils/blockchain.py to include revoke_patient
class BlockchainClient:
    # [Previous methods unchanged]

    @retry()
    def revoke_patient(self, patient_id, role='admin', name='Admin'):
        """
        Revoke patient data from blockchain with role-specific messages.
        
        Args:
            patient_id (int): Patient ID to revoke
            role (str): User role (default: admin)
            name (str): User name (default: Admin)
        
        Returns:
            dict: Revocation result with role-specific message
        """
        try:
            response = requests.delete(f'{BLOCKCHAIN_URL}/patients/{patient_id}', headers=self._get_headers(), timeout=5)
            response.raise_for_status()
            logger.info(f"Patient {patient_id} revoked from blockchain successfully for {role}")
            return {"message": get_role_message(role, "patient data revocation", True, name), "data": response.json()}
        except Exception as e:
            logger.error(f"Error revoking patient: {e}")
            raise Exception(get_role_message(role, "patient data revocation", False, name))

    # [Other methods unchanged]