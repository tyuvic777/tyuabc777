import coverage
import os

def check_coverage():
    cov = coverage.Coverage(source=['../frontend', '../backend', '../blockchain'])
    cov.start()
    # Simulate running all tests (run_all_tests.sh would execute this)
    cov.stop()
    cov.report()
    total_coverage = cov.coverage()
    assert total_coverage >= 97.0, f"Test coverage must be at least 97%, got {total_coverage}%"

if __name__ == '__main__':
    check_coverage()